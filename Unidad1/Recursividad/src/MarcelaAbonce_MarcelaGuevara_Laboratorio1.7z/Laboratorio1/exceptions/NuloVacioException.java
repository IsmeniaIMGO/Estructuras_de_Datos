package Laboratorio1.exceptions;

public class NuloVacioException extends Exception{
    public NuloVacioException(String message) {
        super(message);
    }
}
