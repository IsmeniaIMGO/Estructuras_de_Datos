package Laboratorio1.exceptions;

public class EspacioOcupadoException    extends Exception{
    public EspacioOcupadoException(String message) {
        super(message);
    }
}
