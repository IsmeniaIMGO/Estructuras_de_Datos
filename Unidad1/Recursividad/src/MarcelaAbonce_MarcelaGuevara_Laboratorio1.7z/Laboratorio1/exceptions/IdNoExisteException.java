package Laboratorio1.exceptions;

public class IdNoExisteException    extends Exception{
    public IdNoExisteException(String message) {
        super(message);
    }
}
