package Laboratorio1.exceptions;

public class ParametroVacioException    extends Exception{
    public ParametroVacioException(String message) {
        super(message);
    }
}
