package Laboratorio1.exceptions;

public class IdYaExisteException    extends Exception {
    public IdYaExisteException(String message) {
        super(message);
    }
}
