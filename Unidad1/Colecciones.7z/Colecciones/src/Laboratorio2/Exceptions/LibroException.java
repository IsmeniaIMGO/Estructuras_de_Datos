package Laboratorio2.Exceptions;

public class LibroException extends Exception{
    public LibroException(String s) {
        super (s);
    }

    public LibroException() {
        super ();
    }
}
