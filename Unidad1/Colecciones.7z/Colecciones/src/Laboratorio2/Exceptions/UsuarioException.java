package Laboratorio2.Exceptions;

public class UsuarioException extends Exception{
    public UsuarioException(String s) {
        super (s);
    }

    public UsuarioException() {
        super ();
    }
}
